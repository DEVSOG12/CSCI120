//
// Created by Oreofe Solarin on 8/29/22.
//

#ifndef UNTITLED1_COUNT_H
#define UNTITLED1_COUNT_H

#endif //UNTITLED1_COUNT_H


// countDown function reference from count.cpp
void countDown(int max);

// average function reference from count.cpp
float average(int a, int b, int c);

// isTrue function reference from count.cpp
bool isTrue(bool one, bool two);

// checkME function reference from count.cpp
int checkMe();

// factorial function reference from count.cpp
int factorial(int number);