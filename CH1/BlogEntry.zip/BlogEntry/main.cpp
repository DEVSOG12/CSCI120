//#include <iostream>
//
//
//#include "BlogEntry.h"
//int main() {
////    Text me("2222222");
////
////   cout<< me;
//    BlogEntry mme;
// mme.showStructures();
////    std::cout << "Hello, World!" << std::endl;
//    return 0;
//}
